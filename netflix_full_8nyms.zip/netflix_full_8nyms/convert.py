import numpy as np

utilde=np.load('Utilde.npy')
np.savetxt('Utilde.csv', utilde, delimiter=',')
v=np.load('V.npy')
np.savetxt('V.csv', v, delimiter=',')
exit()

data = np.load('lam.npy')
np.savetxt('lam.csv', data, delimiter=',')
#exit()
data = np.load('P.npy')
np.savetxt('P.csv', data, delimiter=',')
data = np.load('Rvar.npy')
np.savetxt('Rvar.csv', data, delimiter=',')
data = np.load('rows.npy')
np.savetxt('rows.csv', data, delimiter=',')
data = np.load('columns.npy')
np.savetxt('columns.csv', data, delimiter=',')


rtilde = np.dot(utilde.T,v)
np.savetxt('rtilde.csv', rtilde, delimiter=',')
